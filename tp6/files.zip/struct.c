#include "string.h"
#include "stdio.h"
#include "unistd.h"

// Example vulnerable program.
int f (char ** argv)
{
	struct locals {
		char a[64];
		char *p;
	};
	struct locals lv;
    lv.p=lv.a;
    printf ("p=%x\t -- before 1st strcpy\n",lv.p);
    strcpy(lv.p,argv[1]);        // <== vulnerable strcpy()
    printf ("p=%x\t -- after 1st  strcpy\n",lv.p);
    strncpy(lv.p,argv[2],16);
    printf("After second strcpy ;)\n");
}

int main (int argc, char ** argv) {
    f(argv);
    execl("back_to_vul","",0);  //<-- The exec that fails
    printf("End of program\n");
	return 0;
}
